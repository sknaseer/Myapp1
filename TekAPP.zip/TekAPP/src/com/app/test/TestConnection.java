package com.app.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.app.daoservice.DBConnect;

public class TestConnection {
	public Connection conn;
    private PreparedStatement stmt;
   

	public void display() throws SQLException {
		
		DBConnect abc=DBConnect.getDbCon();
		stmt=abc.conn.prepareStatement("select * from test");
		ResultSet rs=stmt.executeQuery();
		while(rs.next())
		{
			
			System.out.println(rs.getString("name"));
			System.out.println(rs.getString("id"));
		}
	}
	
	
	public static void main(String[] args) throws SQLException {
		
		TestConnection tst=new TestConnection();
		tst.display();
		
		
	}
}
