package com.app.daoservice;

import java.util.List;


import com.app.bean.EmployeeBean;

public interface EmpService {
	
	List<EmployeeBean> getSkillMatrixDetails();
	String trainPlanInsertDao(String tname,String courses,String startDate,String endDate);
	List<EmployeeBean> updateTPlanGetDao();
	String traingPlanrowUpdateDao(String tid,String tname,String courses,String startDate,String endDate);
	String traingPlanrowDeleteDao(String tid);
}
