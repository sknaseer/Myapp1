package com.app.daoservice;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.app.bean.EmployeeBean;
import com.app.constants.DBConstant;

public class EmpServiceImpl implements EmpService{
	private Connection conn;
	private PreparedStatement stmt;
	public ResultSet rs;

	@Override
	public List<EmployeeBean> getSkillMatrixDetails() {
		System.out.println("inside DAO Class");
		List<EmployeeBean> list=new ArrayList<EmployeeBean>();
		DBConnect db=DBConnect.getDbCon();
		EmployeeBean empBean=null;
		try {
			stmt=db.conn.prepareStatement(DBConstant.Query_SKILLMATRIX);
			rs=stmt.executeQuery();
			while(rs.next())
			{
				empBean=new EmployeeBean();
				empBean.setEmpID(rs.getString("emp_id"));
				empBean.setEmpFirstName(rs.getString("first_name"));
				empBean.setEmpLastName(rs.getString("last_name"));
				empBean.setEmail(rs.getString("mail_id"));
				empBean.setTotalExperience(rs.getString("total_past_exp"));
				empBean.setSkillName(rs.getString("skill_name"));
				empBean.setSecondaySkills(rs.getString("Other_Skills"));
				empBean.setSkillID(rs.getString("emp_skill_id"));
				empBean.setPrimarySkillID(rs.getString("primary_skill_id"));
				
				list.add(empBean);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public String trainPlanInsertDao(String tname, String courses,
			String startDate, String endDate) {
		// TODO Auto-generated method stub
		DBConnect db=DBConnect.getDbCon();
		SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
		Date stdate,enddate;
		String sdate,edate;
		String msg=null;

		try{
			stdate=(Date) dt.parse(startDate);
			enddate=(Date) dt.parse(endDate);

			sdate = df.format(stdate);
			edate=df.format(enddate);
			System.out.println("startdate---"+sdate);

			stmt=db.conn.prepareStatement(DBConstant.TRAININGPLAN_INSERT);
			stmt.setString(1, tname);
			stmt.setString(2, courses);
			stmt.setString(3, sdate);
			stmt.setString(4, edate);
			int count=stmt.executeUpdate();
			if(count==1)
				msg="Training Plan Sucessfully Inserted ";
		}
		catch (SQLException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}

	@Override
	public List<EmployeeBean> updateTPlanGetDao() {
		// TODO Auto-generated method stub
		List<EmployeeBean> utpList=new ArrayList<EmployeeBean>();
		DBConnect db=DBConnect.getDbCon();
		EmployeeBean empBean=null;
		try {
			stmt=db.conn.prepareStatement(DBConstant.TRAININGPLAN_GET);
			rs=stmt.executeQuery();
			while(rs.next())
			{
				empBean=new EmployeeBean();
				empBean.setTrainingID(rs.getString("training_id"));
				empBean.setTrainingName(rs.getString("training_name"));
				empBean.setCourses(rs.getString("courses_offered"));
				empBean.setStartDate(rs.getString("start_date"));
				empBean.setEndDate(rs.getString("end_date"));
				utpList.add(empBean);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return utpList;

	}

	@Override
	public String traingPlanrowUpdateDao(String tid, String tname,
			String courses, String startDate,String endDate) {
		int trainingID=Integer.parseInt(tid);
		DBConnect db=DBConnect.getDbCon();
		String msg=null;
		try{	
			stmt=db.conn.prepareStatement(DBConstant.TRAININGPLAN_ROWUPDATE);

			stmt.setString(1, tname);
			stmt.setString(2, courses);
			stmt.setString(3, startDate);
			stmt.setString(4, endDate);
			stmt.setInt(5, trainingID);
			int count=stmt.executeUpdate();
			if(count==1)
				msg="Data has been successfully updated";
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}

	@Override
	public String traingPlanrowDeleteDao(String tid) {
		// TODO Auto-generated method stub
		int trainingID=Integer.parseInt(tid);
		DBConnect db=DBConnect.getDbCon();
		String msg=null;
		try{	
			stmt=db.conn.prepareStatement(DBConstant.TRAININGPLAN_ROWDELETE);

			stmt.setInt(1, trainingID);
			int count=stmt.executeUpdate();
			if(count==1)
				msg="Data has been successfully Deleted";
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}

}




