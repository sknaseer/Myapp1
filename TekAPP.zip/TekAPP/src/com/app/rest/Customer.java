package com.app.rest;

public class Customer {
	
	private String cName;
	private String cAge;
	private String cAddress;
	private String cAccountNo;
	private String caccountType;
	
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcAge() {
		return cAge;
	}
	public void setcAge(String cAge) {
		this.cAge = cAge;
	}
	public String getcAddress() {
		return cAddress;
	}
	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}
	public String getcAccountNo() {
		return cAccountNo;
	}
	public void setcAccountNo(String cAccountNo) {
		this.cAccountNo = cAccountNo;
	}
	public String getCaccountType() {
		return caccountType;
	}
	public void setCaccountType(String caccountType) {
		this.caccountType = caccountType;
	}
	
	
	
	
}
