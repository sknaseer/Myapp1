package com.app.constants;

public class DBConstant {

	public static final String DB_URL = "jdbc:mysql://localhost:3306/";
	public static final String DB_DRIVER = "com.mysql.jdbc.Driver";
	public static final String DB_NAME = "mydb";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "root";
	public static final String Query_SKILLMATRIX="SELECT esd.emp_skill_id,esd.skill_desc Other_Skills,esd.Emp_id,emp.first_name,emp.last_name,emp.mail_id,emp.primary_skill_id,pss.skill_name,emp.date_of_joining,emp.total_past_exp FROM EMPLOYEE_SKILL_DETAILS esd,employee emp,primary_skill_sets pss WHERE esd.emp_id=emp.emp_id AND emp.primary_skill_id= pss.skill_id";
	public static final String TRAININGPLAN_INSERT="INSERT INTO trainings_offered(training_name,courses_offered,start_date,end_date) VALUES(?,?,?,?)";
	public static final String TRAININGPLAN_GET="SELECT training_id,training_name,courses_offered,start_date,end_date FROM trainings_offered";
	public static final String TRAININGPLAN_ROWUPDATE="UPDATE trainings_offered SET training_name=?,courses_offered=?,start_date=?,end_date=?,modified_date=CURDATE() WHERE training_id=?";
	public static final String TRAININGPLAN_ROWDELETE="DELETE FROM trainings_offered WHERE training_id=?";
}
