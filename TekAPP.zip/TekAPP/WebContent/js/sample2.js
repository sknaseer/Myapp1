//Define an angular module for our app
var sampleApp2 = angular.module("tekapp1", ["ngRoute","ngTable","datatables","ngSanitize", "ngCsv"]);
sampleApp2.config(function($routeProvider) {
	$routeProvider
	.when("/EmpSkillMatrix", {
		templateUrl : "./pages/skillMatrix.html",
		controller : "skillMatrixController"
	})
	.when("/trainingPlan", {
		templateUrl : "./pages/trainingPlan.html",
		controller : "trainingPController"
	})
	.when("/updateTraningPlan", {
		templateUrl : "./pages/updateTrainingplan.html",
		controller : "updateTplanController"
	})
	.when("/AddProjects", {
		templateUrl : "./pages/addProject.html",
		controller : "addProjectController"
	})
	/*.when("/matc", {
		templateUrl : "./pages/te.html",
		controller : "matcController"
	})*/

});



sampleApp2.controller('myctr', function($scope,$rootScope) {
	$rootScope.myValue = true;
});

sampleApp2.controller('matcController', function($scope,$rootScope) {
	$rootScope.myValue = true;
	alert("test");
});



sampleApp2.controller('skillMatrixController', function($scope,$rootScope,$http,NgTableParams) {
	$rootScope.title="Skill Matrix Page";
	$rootScope.myValue = false;
	$http({
		method: 'GET',
		url: 'rest/myrest/skillMatrix'
	}).success(function(data){
		$scope.list=data;
		/*$('#example').DataTable();*/
	}).error(function(){
		alert("error");
	});	
});

sampleApp2.controller('trainingPController', function($scope,$rootScope,$http) {
	$rootScope.title="Training Plan Page";
	$rootScope.myValue = false;
	$(".datepicker").datepicker({
		changeMonth: true,
		changeYear: true
		/*dateFormat: "yy-mm-dd"*/
	});
	$scope.trainingPlan=function(){
		var startdate=$("#start_date").val();
		var enddate=$("#end_date").val();
		alert("startdate"+$scope.startDate);
		$http({
			method : 'POST',
			url : 'rest/myrest/trngPlanAdd',
			data : $.param({
				'trainingname' : $scope.trngName,
				'courses' : $scope.courses,
				'startdate' : startdate,
				'enddate' :enddate
			}),
			headers : {
				'Content-Type' : 'application/x-www-form-urlencoded'
			}
		}).success(function (data) {
			$scope.result=data;
			if(data!=null)
			{
				$("#training_name").val("");
				$("#courses_").val("");
				$("#start_date").val("");
				$("#end_date").val("");
			}

			alert("result---"+result)
		}).error(function(status){
			alert("status..."+status);
		});
	}

});



sampleApp2.controller('updateTplanController', function($scope,$rootScope,$http,NgTableParams) {
	$rootScope.title="Update Training Plan";
	$rootScope.Success_Msg = false;
	$rootScope.myValue = false;
	$http({
		method: 'GET',
		url: 'rest/myrest/updateTPlan'
	}).success(function(data){
		$rootScope.tabelsData=data;
		/*$rootScope.count=$rootScope.tabelsData.length;
		$scope.tableParams = new NgTableParams({}, { dataset: $rootScope.tabelsData});
*/	}).error(function(){
		alert("error");
	});	

	$scope.editingData = {};

	for (var i = 0; i < $rootScope.count; i++) {
		$scope.editingData[$rootScope.tabelsData[i].trainingID] = false;
	}

	$scope.modify = function(tableData){
		/*alert("table id--"+tableData.trainingID);*/
		$scope.editingData[tableData.trainingID] = true;
	};


	$scope.update = function(tableData){
		$scope.editingData[tableData.trainingID] = false;

		$http({
			method: 'PUT',
			url: 'rest/myrest/updateTPlanRow',
			data : $.param({
				'trainingid' : tableData.trainingID,
				'trainingname' : tableData.trainingName,
				'courses' : tableData.courses,
				'startdate' : tableData.startDate,
				'enddate' :tableData.endDate
			}),
			headers : {
				'Content-Type' : 'application/x-www-form-urlencoded'
			}
		}).success(function(data){

			$rootScope.msg=data;
			$rootScope.Success_Msg = true;
		}).error(function(){
			alert("error");
		});	


	};
	$scope.remove = function(tableData){
		/*$scope.editingData[tableData.trainingID] = false;*/
		if (confirm("Are you sure want to delete?") == true) {
		$http({
			method: 'DELETE',
			url: 'rest/myrest/deleteTPlanRow',
			data : $.param({
				'trainingid' : tableData.trainingID
			}),
			headers : {
				'Content-Type' : 'application/x-www-form-urlencoded'
			}
		}).success(function(data){
			
			$rootScope.msg=data;
			$rootScope.Success_Msg = true;
			if(data!==null)
				{
				$http({
					method: 'GET',
					url: 'rest/myrest/updateTPlan'
				}).success(function(data){
					$rootScope.tabelsData=data;
				})
				
				}
		}).error(function(){
			alert("error");
		});
		}


	};

});


sampleApp2.controller('addProjectController', function($scope,$rootScope,$http) {
	$rootScope.myValue = false;
	$(".datepicker").datepicker({
		changeMonth: true,
		changeYear: true
		/*dateFormat: "yy-mm-dd"*/
	});
	$scope.trainingPlan=function(){
		var startdate=$("#start_date").val();
		var enddate=$("#end_date").val();
		alert("startdate"+$scope.startDate);
		$http({
			method : 'POST',
			url : 'rest/myrest/trngPlanAdd',
			data : $.param({
				'trainingname' : $scope.trngName,
				'courses' : $scope.courses,
				'startdate' : startdate,
				'enddate' :enddate
			}),
			headers : {
				'Content-Type' : 'application/x-www-form-urlencoded'
			}
		}).success(function (data) {
			$scope.result=data;
			if(data!=null)
			{
				$("#training_name").val("");
				$("#courses_").val("");
				$("#start_date").val("");
				$("#end_date").val("");
			}

			alert("result---"+result)
		}).error(function(status){
			alert("status..."+status);
		});
	}

});

sampleApp2.controller('test', function($scope,$http,$rootScope) {
	$rootScope.myValue = true;
	$rootScope.filename = "matc";
	
	$http({
		method: 'GET',
		url: 'rest/myrest/matcCSV'
	}).success(function(data){
		$rootScope.getArray=data;
	}).error(function(){
		alert("error");
	});
	
		
	/* $rootScope.getArray = [{
     name: "John Smith",
     email: "j.smith@example.com",
     dob: "1985-10-10"
 }, {
     name: "Jane Smith",
     email: "jane.smith@example.com",
     dob: "1988-12-22"
 }, {
     name: "Jan Smith",
     email: "jan.smith@example.com",
     dob: "2010-01-02"
 }, {
     name: "Jake Smith",
     email: "jake.smith@exmaple.com",
     dob: "2009-03-21"
 }, {
     name: "Josh Smith",
     email: "josh@example.com",
     dob: "2011-12-12"
 }, {
     name: "Jessie Smith",
     email: "jess@example.com",
     dob: "2004-10-12"
 }]
	*/	
	 $rootScope.getHeader = function () {return ["Employee ID", "Employee Name","Designation","Employee Type","Mail ID","PSFTID","Date_of_joining","TEKExperieance","Total Past Experieance","Total Experieance","Family","Manager","Reporting Manager","Level1Manger","Project Name","Billable","Comments","Requirement Mapping","Organization","Primary Skills","Core or Strategic","Cross_training"]};
		
});


sampleApp2.controller('profileController', function($scope,$rootScope) {
	$rootScope.myValue = false;
});


sampleApp2.controller('allocationController', function($scope,$rootScope) {
	console.log("inside my controller");

	$scope.message = 'This is user My allocation page';
	$rootScope.myValue = false;
});

/*$(document).ready(function() {

    $('#example').DataTable();
} );*/


